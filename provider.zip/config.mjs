import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const localConfigUrl = new URL('./config.json', import.meta.url);
let localConfig = {};

try {
  localConfig = JSON.parse(readFileSync(localConfigUrl, 'utf8'));
} catch (error) {
  if (error.code !== 'ENOENT') {
    throw new Error(`config.json tidak dapat dibaca: ${error.message}`);
  }
}

function section(name) {
  const value = localConfig[name] ?? {};
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error(`Bagian "${name}" di config.json harus berupa objek.`);
  }
  return value;
}

function stringValue(envValue, fileValue, fallback, name) {
  const value = envValue ?? fileValue ?? fallback;
  if (typeof value !== 'string') throw new Error(`Konfigurasi ${name} harus berupa teks.`);
  return value.trim();
}

function numberValue(envValue, fileValue, fallback, name, min, max, integer = false) {
  const rawValue = envValue ?? fileValue ?? fallback;
  const value = typeof rawValue === 'number' ? rawValue : Number(rawValue);
  if (!Number.isFinite(value) || value < min || value > max || (integer && !Number.isSafeInteger(value))) {
    throw new Error(`Konfigurasi ${name} harus berupa angka ${integer ? 'bulat ' : ''}antara ${min} dan ${max}.`);
  }
  return value;
}

const serverConfig = section('server');
const adminConfig = section('admin');
const providerConfig = section('provider');
const storageConfig = section('storage');
const smsCodeConfig = section('smscode');
const apiUrl = stringValue(undefined, providerConfig.apiUrl, 'https://pusatpanelsmm.com/api/json.php', 'provider.apiUrl');
const apiKey = stringValue(process.env.PUSAT_PANEL_API_KEY, providerConfig.apiKey, '', 'provider.apiKey');
const secretKey = stringValue(process.env.PUSAT_PANEL_SECRET_KEY, providerConfig.secretKey, '', 'provider.secretKey');

if (new URL(apiUrl).protocol !== 'https:') {
  throw new Error('provider.apiUrl harus menggunakan HTTPS.');
}
if (Boolean(apiKey) !== Boolean(secretKey)) {
  throw new Error('provider.apiKey dan provider.secretKey harus diisi bersama-sama.');
}

export const config = Object.freeze({
  server: Object.freeze({
    host: stringValue(process.env.HOST, serverConfig.host, '127.0.0.1', 'server.host'),
    port: numberValue(process.env.PORT, serverConfig.port, 8000, 'server.port', 1, 65535, true),
    nodeEnv: stringValue(process.env.NODE_ENV, serverConfig.nodeEnv, 'development', 'server.nodeEnv'),
  }),
  admin: Object.freeze({
    topupKey: stringValue(process.env.TOPUP_ADMIN_KEY, adminConfig.topupKey, '', 'admin.topupKey'),
  }),
  provider: Object.freeze({
    apiUrl,
    apiKey,
    secretKey,
    timeoutMs: numberValue(process.env.PUSAT_PANEL_TIMEOUT_MS, providerConfig.timeoutMs, 20000, 'provider.timeoutMs', 1000, 120000, true),
    markupPercent: numberValue(process.env.SMM_MARKUP_PERCENT, providerConfig.markupPercent, 0, 'provider.markupPercent', 0, 10000),
  }),
  smscode: Object.freeze({
    token: stringValue(process.env.SMSCODE_TOKEN, undefined, '', 'smscode.token'),
    countryId: numberValue(process.env.SMSCODE_COUNTRY_ID, smsCodeConfig.countryId, 7, 'smscode.countryId', 1, 2147483647, true),
    markupPercent: numberValue(process.env.SMSCODE_MARKUP_PERCENT, smsCodeConfig.markupPercent, 0, 'smscode.markupPercent', 0, 10000),
  }),
  storage: Object.freeze({
    directory: stringValue(undefined, storageConfig.directory, 'data', 'storage.directory'),
  }),
});

export const projectDirectory = fileURLToPath(new URL('.', import.meta.url));
